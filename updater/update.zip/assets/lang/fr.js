module.exports = {
	noUpdate:"Pas de mise a jour disponible",
	UpdateCompleted:"Mise a jour effectué",
	EnterUrl:"Entrez l'URL d'un site Web",
	addButton:"Ajouter",
	CancelButton:"Annuler",
	ContinueButton:"Continuer",
	Remove: "Suprimer ",
	FBM: " des favoris ?",
	restartApp: "Vos modifications seront appliquées dès le prochain redémarrage de Shuttle.",
	SAboot: "lancer au démarage",
	SOpen: "laisser actif"
};