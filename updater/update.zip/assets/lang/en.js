module.exports = {
	noUpdate:"No update avalible",
	UpdateCompleted:"Update complete !",
	EnterUrl:"Enter the url of a website",
	addButton:"Add",
	CancelButton:"Cancel",
	ContinueButton:"Continue",
	Remove: "Remove ",
	FBM: " from bookmarks ?",
	restartApp: "Your modifications will be applied from the next restart of Shuttle."
	SAboot: "start at boot",
	SOpen: "stay open"
};